#!/usr/bin/env python3
"""Reject partial or stale raw captures before any edit is encoded."""
import json,struct,sys
from pathlib import Path
root=Path(__file__).resolve().parent.parent
report=json.loads((root/'qa/done.json').read_text())
shots=json.loads((root/'raw/shots.json').read_text())
assert report['kind']=='full','Capture has not finished'
assert len(report['metrics'])==sum(s['frames'] for s in shots)==954
assert report.get('startedAt'), 'No capture run timestamp'
for shot in shots:
 frames=sorted((root/'raw'/shot['id']).glob('*.png'))
 assert len(frames)==shot['frames'],f"Incomplete {shot['id']}"
 for i,file in enumerate(frames):
  assert file.name==f'{i:04}.png'
  assert file.stat().st_mtime>=report['startedAt']/1000-1,'Stale frame'
  with file.open('rb') as f:
   header=f.read(24)
  assert header[:8]==b'\x89PNG\r\n\x1a\n'
  assert struct.unpack('>II',header[16:24])==(1920,1080)
m=report['metrics']
for shot in ['walk','drive','boat']:
 f=[x for x in m if x['shot']==shot]
 assert sum((a-b)**2 for a,b in zip(f[0]['position'],f[-1]['position']))>1,shot+' did not move'
f=[x for x in m if x['shot']=='return']
assert {x['mode'] for x in f}=={'drive','orbit'}
assert f[0]['position']==f[-1]['position']
assert f[0]['mode']==f[-1]['mode']=='drive'
print('PASS: 954 fresh 1080p frames; three travel modes move; local-map return preserves position.')
