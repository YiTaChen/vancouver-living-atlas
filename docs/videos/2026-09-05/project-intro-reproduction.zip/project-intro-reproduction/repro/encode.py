#!/usr/bin/env python3
"""Create the delivery H.264 MP4 from the 900 edited frames."""
import argparse,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('ffmpeg');p.add_argument('--frames',default='edited');p.add_argument('--count',default=900,type=int);p.add_argument('--output',default='project-intro.mp4');a=p.parse_args()
Path(a.output).parent.mkdir(parents=True,exist_ok=True)
subprocess.run([a.ffmpeg,'-hide_banner','-y','-framerate','30','-i',str(Path(a.frames)/'%04d.png'),'-frames:v',str(a.count),'-an','-vf','scale=out_color_matrix=bt709:out_range=tv,format=yuv420p','-c:v','libx264','-preset','slow','-crf','18','-profile:v','high','-level:v','4.2','-pix_fmt','yuv420p','-r','30','-fps_mode','cfr','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-movflags','+faststart','-metadata','title=Vancouver | Living Atlas','-metadata','comment=Captured from the running Vancouver Living Atlas browser application. Rail and harbour movements are illustrative.',a.output],check=True)
