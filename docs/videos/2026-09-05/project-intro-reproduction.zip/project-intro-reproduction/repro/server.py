#!/usr/bin/env python3
"""Loopback-only static film studio and bounded PNG/JSON capture sink."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import argparse,json,re
p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=3004);a=p.parse_args()
ROOT=Path(__file__).resolve().parent.parent
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT/'app/dist/client'),**kwargs)
 def log_message(self,fmt,*args):pass
 def do_GET(self):
  path=urlparse(self.path).path
  if path=='/review':
   name='capability-test.mp4' if 'test' in urlparse(self.path).query else 'project-intro.mp4'
   body=f'<html><head><title>Vancouver film review</title><style>body{{margin:0;background:#10212b;color:white;font:18px sans-serif}}video{{width:100vw;height:85vh}}</style></head><body><video src="/media/{name}" controls autoplay muted playsinline></video><p>Vancouver Living Atlas | {name}</p></body></html>'.encode()
   self.send_response(200);self.send_header('Content-Type','text/html');self.end_headers();self.wfile.write(body);return
  if path.startswith('/media/'):
   name=path.removeprefix('/media/')
   if name not in ['project-intro.mp4','capability-test.mp4']:self.send_error(404);return
   file=ROOT/'deliverables'/name
   if not file.exists():self.send_error(404);return
   self.send_response(200);self.send_header('Content-Type','video/mp4');self.send_header('Content-Length',str(file.stat().st_size));self.end_headers()
   with file.open('rb') as f:
    while chunk:=f.read(1024*1024):self.wfile.write(chunk)
   return
  return super().do_GET()
 def do_POST(self):
  if self.headers.get('Origin') not in [f'http://127.0.0.1:{a.port}',f'http://localhost:{a.port}']:self.send_error(403);return
  match=re.fullmatch(r'/__capture/(raw|qa)/([a-z0-9_-]+)/(\d{4}\.png)',urlparse(self.path).path)
  report=re.fullmatch(r'/__capture/(shots|capabilities|progress|done|error)\.json',urlparse(self.path).path)
  if not match and not report:self.send_error(404);return
  length=int(self.headers.get('Content-Length','0'))
  if length<1 or length>12_000_000:self.send_error(413);return
  data=self.rfile.read(length)
  if match:
   if not data.startswith(b'\x89PNG\r\n\x1a\n'):self.send_error(415);return
   dest=ROOT/match[1]/match[2]/match[3]
  else:
   try:json.loads(data)
   except ValueError:self.send_error(400);return
   dest=ROOT/('raw' if report[1]=='shots' else 'qa')/(report[1]+'.json')
  dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  self.send_response(200);self.end_headers();self.wfile.write(b'ok')
print(f'Film studio http://127.0.0.1:{a.port}/',flush=True)
ThreadingHTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
