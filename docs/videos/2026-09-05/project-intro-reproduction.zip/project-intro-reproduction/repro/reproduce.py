#!/usr/bin/env python3
"""One-command reproduction: isolated app → real browser → frames → MP4.
Requires Node 22.13+, a WebGL2 browser, Pillow, and FFmpeg with libx264.
No cloud, deployment or video generation is used.
"""
import argparse,os,subprocess,sys,tarfile,time,json,urllib.request,webbrowser
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--ffmpeg',default='ffmpeg');a=p.parse_args()
root=Path(__file__).resolve().parent.parent;os.chdir(root)
if not (root/'app').exists():
 with tarfile.open(root/'app-snapshot.tar.gz') as archive:archive.extractall(root,filter='data')
if not (root/'app/node_modules').exists():subprocess.run(['npm','ci'],cwd=root/'app',check=True)
subprocess.run(['npm','run','build:firebase'],cwd=root/'app',check=True)
# Refuse an occupied port instead of sharing a possibly unrelated server.
import socket
with socket.socket() as sock:
 if sock.connect_ex(('127.0.0.1',3004))==0:raise SystemExit('Port 3004 is already in use. Stop the earlier local film server before reproducing.')
(root/'qa').mkdir(exist_ok=True)
server=subprocess.Popen([sys.executable,'repro/server.py'])
try:
 for _ in range(100):
  try:
   urllib.request.urlopen('http://127.0.0.1:3004/',timeout=1).close();break
  except OSError:time.sleep(.2)
 started=time.time();webbrowser.open('http://127.0.0.1:3004/?film=render',new=2)
 print('Rendering the running app. Keep this browser tab open until complete.',flush=True)
 last=''
 while True:
  err=root/'qa/error.json'
  if err.exists() and err.stat().st_mtime>started:raise RuntimeError(err.read_text())
  done=root/'qa/done.json'
  if done.exists() and done.stat().st_mtime>started:
   data=json.loads(done.read_text())
   if data.get('kind')=='full' and data.get('startedAt',0)/1000>=started-1:break
  progress=root/'qa/progress.json'
  if progress.exists():
   msg=progress.read_text()
   if msg!=last:print(msg,flush=True);last=msg
  if time.time()-started>3600:raise TimeoutError('Browser capture did not complete within one hour.')
  time.sleep(2)
 subprocess.run([sys.executable,'repro/verify-capture.py'],check=True)
 subprocess.run([sys.executable,'repro/compose.py'],check=True)
 subprocess.run([sys.executable,'repro/encode.py',a.ffmpeg,'--output','deliverables/project-intro.mp4'],check=True)
 subprocess.run([sys.executable,'repro/verify-video.py','deliverables/project-intro.mp4',a.ffmpeg,'--json','qa/video-verification.json'],check=True)
 print('Completed: '+str(root/'deliverables/project-intro.mp4'))
finally:server.terminate();server.wait()
