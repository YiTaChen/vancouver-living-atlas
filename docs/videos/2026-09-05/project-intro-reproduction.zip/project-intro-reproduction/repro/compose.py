#!/usr/bin/env python3
"""Finish actual app frames with English typography and nine-frame dissolves."""
import argparse, json, os, functools
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageChops
p=argparse.ArgumentParser(); p.add_argument('--raw',default='raw'); p.add_argument('--out',default='edited'); p.add_argument('--indices'); a=p.parse_args()
root=Path(a.raw); out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
shots=json.loads((root/'shots.json').read_text()); W,H=1920,1080
@functools.lru_cache()
def font(size,bold=False):
 key='FILM_FONT_BOLD' if bold else 'FILM_FONT'
 fallback='/System/Library/Fonts/Supplemental/Arial Bold.ttf' if bold else '/System/Library/Fonts/Supplemental/Arial.ttf'
 return ImageFont.truetype(os.environ.get(key,fallback),size)
def smooth(x):
 x=max(0,min(1,x)); return x*x*(3-2*x)
def load(s,i):
 with Image.open(root/s['id']/f'{i:04}.png') as image:
  if image.size!=(W,H):raise ValueError('Unexpected capture dimensions')
  return image.convert('RGB')
def text(draw,position,value,size=28,color=(238,244,242,255),bold=False):
 draw.text(position,value,font=font(size,bold),fill=color,anchor='lt',stroke_width=1,stroke_fill=(9,25,31,60))
credit=Image.new('RGBA',(W,H)); dc=ImageDraw.Draw(credit)
for y in range(960,H):dc.line((0,y,W,y),fill=(5,24,32,int(110*((y-960)/120)**1.5)))
dc.text((1864,1020),'Map data © OpenStreetMap contributors · ODbL',font=font(18),fill=(245,250,249,235),anchor='rt')
dc.text((1864,1046),'City of Vancouver · Terrain: NRCan / USGS',font=font(16),fill=(230,240,236,220),anchor='rt')

# Extra local scrim keeps white walking captions readable against the bright sky.
walk_scrim=Image.new('RGBA',(W,H),(5,24,32,0))
v=Image.new('L',(W,H));dv=ImageDraw.Draw(v)
for y in range(550):dv.line((0,y,W,y),fill=int(242*max(0,1-y/550)**1.25))
h=Image.new('L',(W,H));dh=ImageDraw.Draw(h)
for x in range(1450):dh.line((x,0,x,H),fill=round(255*(1-smooth((x-750)/700))))
walk_scrim.putalpha(ImageChops.multiply(v,h))

def decorate(im,s,i,n):
 overlay=Image.new('RGBA',(W,H)); d=ImageDraw.Draw(overlay); t=i/30; duration=s['frames']/30
 opacity=smooth((i-3)/9)*smooth((s['frames']-i-7)/10)
 if s['id']=='coast':opacity=smooth((i+4)/10)*smooth((s['frames']-i-7)/10)
 if s['id']=='light':
  opacity=smooth((i-3)/9)
  if n>=840:opacity*=smooth((n-838)/9)
  elif n>=831:opacity*=smooth((840-n)/9)
 # Restrained title area; the street, actor and cockpit remain unobstructed.
 if s['id']=='walk':overlay=walk_scrim.copy();d=ImageDraw.Draw(overlay)
 else:
  for y in range(365):d.line((0,y,W,y),fill=(5,24,32,int(130*max(0,1-y/365)**1.8)))
 mint=(224,237,161,255); x,y=82,66
 d.rounded_rectangle((x,y,x+42,y+5),radius=2,fill=mint)
 if s['id']=='coast':
  text(d,(x,y+28),'Vancouver',76,bold=True)
  text(d,(x+2,y+111),'Living Atlas',38,color=mint)
  text(d,(x+2,y+166),'An interactive city, built for the browser.',28)
 else:
  title=s['title']; subtitle=s['subtitle']
  if s['id']=='landmark':subtitle='Original 3D models. Ultra detail.'
  if s['id']=='boat':subtitle='Explore with waves and momentum.'
  if s['id']=='return':title='Zoom out. Come back.';subtitle='Look around. Resume where you left off.'
  if s['id']=='light' and n>=840:
   title='Vancouver · Living Atlas';subtitle='Explore a city between forest and sea.'
   text(d,(x+2,y+146),'BUILT FOR THE BROWSER',18,color=mint)
  text(d,(x,y+28),title,52,bold=True)
  text(d,(x+2,y+91),subtitle,28)
 if opacity<1:overlay.putalpha(overlay.getchannel('A').point(lambda v:round(v*opacity)))
 im=Image.alpha_composite(im.convert('RGBA'),overlay)
 return Image.alpha_composite(im,credit).convert('RGB')
indices=[int(n) for n in a.indices.split(',')] if a.indices else range(900)
for n in indices:
 active=[s for s in shots if s['start']<=n<s['start']+s['frames']]
 if len(active)==1:
  s=active[0];im=load(s,n-s['start'])
 else:
  old,s=active; im=Image.blend(load(old,n-old['start']),load(s,n-s['start']),smooth((n-s['start'])/8))
 im=decorate(im,s,n-s['start'],n);im.save(out/f'{n:04}.png',compress_level=2)
 if n%90==0:print(f'EDIT {n}/900',flush=True)
print(f'Wrote {len(indices)} edited frames.',flush=True)
