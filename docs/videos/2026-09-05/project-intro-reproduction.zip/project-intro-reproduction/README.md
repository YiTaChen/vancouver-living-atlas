# Vancouver Living Atlas — film 02

The deliverable is the finished **project-intro.mp4**: 30 seconds, 1920 × 1080, 30 fps, H.264 High Profile, yuv420p, BT.709, web fast-start. Silent by design. English titles and concise subtitles are burned in. No generated video, stock footage or external paid service is used.

This package retains the exact local application snapshot and the capture/edit/encode scripts. It is separate from the working repository. No repository push, remote main modification or deployment is part of this workflow.

## Reproduce

The supplied command targets macOS/Linux. Native Windows requires adapting npm invocation and POSIX environment-variable syntax.

Requirements: Python 3.12+, Pillow, Node 22.13+ with npm, FFmpeg with libx264, and a desktop browser with WebGL 2 and a working GPU. Arial Regular/Bold are used on macOS; alternatively set `FILM_FONT` and `FILM_FONT_BOLD` to local TrueType fonts. Font substitution changes typography.

From the extracted package:

```sh
python3 -m pip install -r repro/requirements.txt
python3 repro/reproduce.py --ffmpeg /absolute/path/to/ffmpeg
```

The command extracts the included app snapshot, installs locked app dependencies if absent, creates a **local static build only**, starts a server bound to 127.0.0.1:3004, opens the real application in the default browser, renders the camera sequence, validates all captured frames, adds typography and dissolves, encodes and checks the MP4. The script does not deploy or interact with Git remotes. Keep the browser tab open during the capture. Set your normal `BROWSER` environment variable if a particular installed browser is required. Use a clean browser session if GPU access is disabled by unrelated browser settings.

The final file is `deliverables/project-intro.mp4`. `qa/video-verification.json` contains the full-decode, codec, duration, frame-count, black-frame and fast-start checks. `qa/done.json` contains real per-frame positions, travel modes, camera positions, speed and simulation time. `verify-capture.py` rejects partial or stale recordings before encoding.

To inspect or rerun a short test manually, run `python3 repro/server.py` and open `http://127.0.0.1:3004/?film=studio`. The visible local-only panel provides scene previews, a 2-second test, probe captures, and the full film. The full-film button starts a fresh app document. Production itself uses `?film=render` to begin automatically.

## How the film was made

- Source: the project's current `feature/ultra-landmarks` snapshot, commit `fd2e9a2` (full SHA in source-commit.txt).
- Seven shots: peninsula, Canada Place, third-person walk on Beach Ave, left-hand-drive cockpit on Robson, sailing in False Creek, zoom to local map and resume driving at the same coordinate, and Science World changing from late afternoon to night.
- The app's own Three.js renderer, original models, Ultra quality, navigation, physics, coastline, collision and day/night systems render every source frame at 1920 × 1080.
- A local-only filming module supplies camera paths and movement input with a fixed 1/30-second simulation step. Travel-map-return calls the existing app zoom behavior. It does not animate a fake return or introduce a new user feature.
- The filming module hides normal UI for cinematic framing and adds only a local capture panel. The recorded pixels are the actual 3D render canvas. Geography/model limitations of the current project remain visible rather than being replaced with other imagery.
- Tree textures and shader compilation are awaited. Actors and smoke are reset for a consistent take. A fixed time source replaces the walker's wall-clock animation and the camera transition uses the supplied frame time. These changes exist only in the snapshot.
- 954 source frames contain six 9-frame overlaps. Pillow adds English typography and smooth dissolves to create exactly 900 finished frames. FFmpeg encodes them at CRF 18 using libx264.
- Exact encoded bytes can vary between GPU drivers, browser versions, fonts and encoder builds. The shot sequence, actions, timing and source snapshot are retained.

## Credits and rights

Code and original procedural models: Vancouver Living Atlas, MIT (see app/LICENSE). Geographic data retains its own terms, detailed in app/DATA_SOURCES.md. On-screen attribution is retained in the film: © OpenStreetMap contributors / ODbL; City of Vancouver; terrain NRCan / USGS. The city is an illustrative 3D geographic visualization, not a photographic reconstruction or live transport feed. Aircraft, train and harbour movements are illustrative. No narration or music is included.
